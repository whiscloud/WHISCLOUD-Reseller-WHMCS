<?php

namespace ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Calls;

use ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Core\Call;

/**
 * Description of GetDomainSuggestions
 *
 * @author inbs
 */
class GetDomainSuggestions extends Call
{
    public $action = "domains/lookup/suggestions";

    public $type = parent::TYPE_POST;
}