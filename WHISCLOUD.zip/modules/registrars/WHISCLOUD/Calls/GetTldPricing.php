<?php

namespace ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Calls;

use ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Core\Call;

class GetTldPricing extends Call
{
    public $action = "tlds/pricing";

    public $type = parent::TYPE_GET;
}