<?php
namespace ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Calls;
use ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Core\Call;

/**
 * Description of RenewDomain
 *
 * @author inbs
 */
class RenewDomain extends Call
{
    public $action = "order/domains/renew";
    
    public $type = parent::TYPE_POST;
}